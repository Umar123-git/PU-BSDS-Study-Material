import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# ── Load ──────────────────────────────────────────────
train = pd.read_csv('train_u6lujuX_CVtuZ9i.csv')
test  = pd.read_csv('test_Y3wMUE5_7gLdaTN.csv')
sub   = pd.read_csv('sample_submission_49d68Cx.csv')

# ── Preprocess ────────────────────────────────────────
def preprocess(df):
    df = df.copy()
    for col in ['Gender', 'Married', 'Dependents', 'Self_Employed', 'Loan_Amount_Term', 'Credit_History']:
        if df[col].dtype == object:
            df[col] = df[col].fillna(df[col].mode()[0])
        else:
            df[col] = df[col].fillna(df[col].mode()[0])
    df['LoanAmount'] = df['LoanAmount'].fillna(df['LoanAmount'].median())
    le = LabelEncoder()
    for col in ['Gender', 'Married', 'Dependents', 'Education', 'Self_Employed', 'Property_Area']:
        df[col] = le.fit_transform(df[col].astype(str))
    return df

train_p = preprocess(train)
test_p  = preprocess(test)

features = ['Gender', 'Married', 'Dependents', 'Education', 'Self_Employed',
            'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
            'Loan_Amount_Term', 'Credit_History', 'Property_Area']

X = train_p[features]
y = (train_p['Loan_Status'] == 'Y').astype(int)
X_test_final = test_p[features]

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)


# ═══════════════════════════════════════════════════════
# Step 1 — Decision Tree
# ═══════════════════════════════════════════════════════
class DecisionTreeModel:
    def __init__(self, max_depth=5):
        self.max_depth = max_depth
        self.model = DecisionTreeClassifier(max_depth=self.max_depth, random_state=42)

    def train(self, X_train, y_train):
        self.model.fit(X_train, y_train)

    def predict(self, X_test):
        return self.model.predict(X_test)

    def evaluate(self, y_test, y_pred):
        accuracy  = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall    = recall_score(y_test, y_pred)
        return accuracy, precision, recall


print("=" * 55)
print("TASK 1.2 — Decision Tree Experiments")
print("=" * 55)
print(f"{'Depth':<10} {'Accuracy':>10} {'Precision':>10} {'Recall':>10}")
print("-" * 55)

dt_best_model, dt_best_acc, best_depth = None, 0, None

for depth in [2, 5, None]:
    m = DecisionTreeModel(max_depth=depth)
    m.train(X_train, y_train)
    preds = m.predict(X_val)
    acc, prec, rec = m.evaluate(y_val, preds)
    label = str(depth) if depth is not None else "None"
    print(f"{label:<10} {acc:>10.4f} {prec:>10.4f} {rec:>10.4f}")
    if acc > dt_best_acc:
        dt_best_acc, dt_best_model, best_depth = acc, m, depth

print("-" * 55)
print(f"Best depth: {best_depth}  (Accuracy: {dt_best_acc:.4f})")


# ═══════════════════════════════════════════════════════
# Step 2 — Random Forest
# ═══════════════════════════════════════════════════════
class RandomForestModel:
    def __init__(self, n_estimators=100):
        self.n_estimators = n_estimators
        self.model = RandomForestClassifier(n_estimators=self.n_estimators, random_state=42)

    def train(self, X_train, y_train):
        self.model.fit(X_train, y_train)

    def predict(self, X_test):
        return self.model.predict(X_test)

    def evaluate(self, y_test, y_pred):
        accuracy  = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall    = recall_score(y_test, y_pred)
        return accuracy, precision, recall


print()
print("=" * 55)
print("TASK 2.2 — Random Forest Experiments")
print("=" * 55)
print(f"{'n_estimators':<14} {'Accuracy':>10} {'Precision':>10} {'Recall':>10}")
print("-" * 55)

rf_best_model, rf_best_acc, best_n = None, 0, None

for n in [10, 50, 100]:
    m = RandomForestModel(n_estimators=n)
    m.train(X_train, y_train)
    preds = m.predict(X_val)
    acc, prec, rec = m.evaluate(y_val, preds)
    print(f"{n:<14} {acc:>10.4f} {prec:>10.4f} {rec:>10.4f}")
    if acc > rf_best_acc:
        rf_best_acc, rf_best_model, best_n = acc, m, n

print("-" * 55)
print(f"Best n_estimators: {best_n}  (Accuracy: {rf_best_acc:.4f})")

# ── Submission ────────────────────────────────────────
rf_best_model.model.fit(X, y)
sub_preds = rf_best_model.predict(X_test_final)
sub['Loan_Status'] = ['Y' if p == 1 else 'N' for p in sub_preds]
sub.to_csv('submission.csv', index=False)
print("\nSubmission saved to submission.csv")
